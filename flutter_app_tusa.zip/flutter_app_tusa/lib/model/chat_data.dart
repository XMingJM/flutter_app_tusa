

class ChatData{
  String chatName;
  String chatMessage;

}